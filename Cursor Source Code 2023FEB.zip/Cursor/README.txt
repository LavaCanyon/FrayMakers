This is a collection of the source code of my FrayMakers customs to help the modding scene of the game.
You may use them for any need. No need to ask or give credit. Have venture.

-----
(Creating New Costume)
Step 1: Duplicate animations into new catagory in Character.entity
Step 2: Create Animation table in Script.hx
Step 3: Add new set of Hitboxes in HitboxStats.hx
Step 3: Find PNG files and put them in the Body folder
Step 4: Begin Editing the animations in Character.entity
-----
